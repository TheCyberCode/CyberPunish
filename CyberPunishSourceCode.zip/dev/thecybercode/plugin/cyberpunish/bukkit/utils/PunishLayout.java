package dev.thecybercode.plugin.cyberpunish.bukkit.utils;

import dev.thecybercode.devapi.CyberDevAPI;
import dev.thecybercode.plugin.cyberpunish.bukkit.database.userBanData;
import litebans.api.Database;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class PunishLayout {

    public static void punishUser(Player staff, ItemStack clicked) {
        String victim = Bukkit.getOfflinePlayer(userBanData.getUUIDToBan(staff)).getName();
        /// Utility.consoleLog("Warn count: "+ new warnCount(userBanData.getUUIDToBan(staff)));
        if (victim == null || staff == null) {
            return;
        }
        if (!staff.hasPermission(Utility.getCore().getConfig().getString("permission").toLowerCase())) {
            staff.sendMessage(CyberDevAPI.ChatColour("&cYou must be staff or higher to do that!"));
            return;
        }
        if (Bukkit.getOfflinePlayer(staff.getUniqueId()).equals(Bukkit.getOfflinePlayer(userBanData.getUUIDToBan(staff)))) {
            CyberDevAPI.send(staff, "&cYou cannot punish yourself.");
            return;
        }
        if (Bukkit.getOfflinePlayer(userBanData.getUUIDToBan(staff)).isOp()) {
            CyberDevAPI.send(staff, "&cYou cannot punish this user.");
            return;
        }

        new BukkitRunnable() {
            /**
             * When an object implementing interface <code>Runnable</code> is used
             * to create a thread, starting the thread causes the object's
             * <code>run</code> method to be called in that separately executing
             * thread.
             * <p>
             * The general contract of the method <code>run</code> is that it may
             * take any action whatsoever.
             *
             * @see Thread#run()
             */
            @Override
            public void run() {
                boolean banned = Database.get().isPlayerBanned(userBanData.getUUIDToBan(staff), null);
                boolean muted = Database.get().isPlayerMuted(userBanData.getUUIDToBan(staff), null);
                if (banned) {
                    CyberDevAPI.send(staff, "&cThis user is already punished!");
                    return;
                }
                int warnCount = 0;
                int banCount = 0;
                int muteCount = 0;
                try {
                    String uuid = userBanData.getUUIDToBan(staff).toString();
                    String query = "SELECT * FROM {punishType} WHERE uuid=?";
                    try (PreparedStatement st = Database.get().prepareStatement(query.replace("punishType", "warnings"))) {
                        st.setString(1, uuid);
                        try (ResultSet rs = st.executeQuery()) {
                            while (rs.next()) {
                                warnCount++;
                                String reason = rs.getString("reason");
                                String bannedByUuid = rs.getString("banned_by_uuid");
                                long time = rs.getLong("time");
                                long until = rs.getLong("until");
                                long id = rs.getLong("id");
                                boolean active = rs.getBoolean("active");
                            }
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                    try (PreparedStatement st = Database.get().prepareStatement(query.replace("punishType", "bans"))) {
                        st.setString(1, uuid);
                        try (ResultSet rs = st.executeQuery()) {
                            while (rs.next()) {
                                banCount++;
                                String reason = rs.getString("reason");
                                String bannedByUuid = rs.getString("banned_by_uuid");
                                long time = rs.getLong("time");
                                long until = rs.getLong("until");
                                long id = rs.getLong("id");
                                boolean active = rs.getBoolean("active");
                            }
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                    try (PreparedStatement st = Database.get().prepareStatement(query.replace("punishType", "mutes"))) {
                        st.setString(1, uuid);
                        try (ResultSet rs = st.executeQuery()) {
                            while (rs.next()) {
                                muteCount++;
                                String reason = rs.getString("reason");
                                String bannedByUuid = rs.getString("banned_by_uuid");
                                long time = rs.getLong("time");
                                long until = rs.getLong("until");
                                long id = rs.getLong("id");
                                boolean active = rs.getBoolean("active");
                            }
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                    ////  CyberDevAPI.send(staff, "Warn count: " + warnCount);
                } finally {
                    if (!staff.hasPermission(Utility.getCore().getConfig().getString("permission").toLowerCase())) {
                        staff.sendMessage(CyberDevAPI.ChatColour("&cYou must be staff or higher to do that!"));
                        return;
                    }
                    String offenseTime = String.valueOf((banCount));
                    String type = Utility.getCore().getConfig().getString("punishments." + clicked.getItemMeta().getDisplayName().toLowerCase().replace(CyberDevAPI.ChatColour(Utility.getCore().getConfig().getString("item-name-colour").trim()), "") + ".type");
                    ///            String time = Utility.getCore().getConfig().getString("punishments." + clicked.getItemMeta().getDisplayName().toLowerCase().replace(CyberDevAPI.ChatColour(Utility.getCore().getConfig().getString("item-name-colour").trim()), "") + ".time.final");
                    String reason = Utility.getCore().getConfig().getString("punishments." + clicked.getItemMeta().getDisplayName().toLowerCase().replace(CyberDevAPI.ChatColour(Utility.getCore().getConfig().getString("item-name-colour").trim()), "") + ".reason");
                    try {
                        String custom_perm = Utility.getCore().getConfig().getString("punishments." + clicked.getItemMeta().getDisplayName().toLowerCase().replace(CyberDevAPI.ChatColour(Utility.getCore().getConfig().getString("item-name-colour").trim()), "") + ".permission");
                        if (custom_perm != null) {
                            if (!staff.hasPermission(custom_perm.toLowerCase().trim())) {
                                CyberDevAPI.send(staff, "&cYou do not have access to this punishment type.");
                                staff.closeInventory();
                                return;
                            }
                        }
                    } catch (Exception err) {
                        Utility.consoleError(err.getMessage());
                    }
                    ////String reason = null;
                    staff.sendMessage(ChatColor.DARK_AQUA + "Bans: " + banCount + " Warns: " + warnCount + " Mutes: " + muteCount);
                    try {
//                        if (Utility.getCore().getConfig().isConfigurationSection("punishments." + clicked.getItemMeta().getDisplayName().toLowerCase().replace(CyberDevAPI.ChatColour(Utility.getCore().getConfig().getString("item-name-colour").trim()), "") + ".time." + offenseTime)) {
//                            time = Utility.getCore().getConfig().getString("punishments." + clicked.getItemMeta().getDisplayName().toLowerCase().replace(CyberDevAPI.ChatColour(Utility.getCore().getConfig().getString("item-name-colour").trim()), "") + ".time." + offenseTime);
//                        } else {
//                            if (Utility.getCore().getConfig().isConfigurationSection("punishments." + clicked.getItemMeta().getDisplayName().toLowerCase().replace(CyberDevAPI.ChatColour(Utility.getCore().getConfig().getString("item-name-colour").trim()), "") + ".time." + "final")) {
//                                time = Utility.getCore().getConfig().getString("punishments." + clicked.getItemMeta().getDisplayName().toLowerCase().replace(CyberDevAPI.ChatColour(Utility.getCore().getConfig().getString("item-name-colour").trim()), "") + ".time." + "final");
//                            }
//                        }

                        try {
                            if (Utility.getCore().getConfig().getBoolean("silent-punish")) {
                                reason = reason + " " + "-s";
                            }
                        } catch (Exception err) {
                            Utility.consoleLog(err.getMessage());
                        }
                    } finally {
                        if (type == null || timeCalc(clicked, banCount) == null || reason == null || staff == null) {
                            return;
                        } else {
                            try {
                                if (Utility.getCore().getConfig().getBoolean("warn-on-first-offense")) {
                                    if (warnCount > 0) {
                                        if (Utility.getCore().getConfig().getBoolean("use-staff-perms")) {
                                            if (type.contains("mute")) {
                                                if (muted) {
                                                    CyberDevAPI.send(staff, "&cThis user is already muted!");
                                                    return;
                                                }
                                                staff.chat("/" + typeCommand(type.trim()) + " " + victim.trim() + " " + timeCalc(clicked, muteCount) + " " + reason);
                                            } else {
                                                staff.chat("/" + typeCommand(type.trim()) + " " + victim.trim() + " " + timeCalc(clicked, banCount) + " " + reason);
                                            }
                                        } else {
                                            if (type.contains("mute")) {
                                                if (muted) {
                                                    CyberDevAPI.send(staff, "&cThis user is already muted!");
                                                    return;
                                                }
                                                Bukkit.getServer().dispatchCommand(Bukkit.getConsoleSender(), type.trim() + " " + timeCalc(clicked, muteCount) + " " + victim.trim() + " " + "--sender=" + staff.getPlayer().getName() + " " + reason);
                                            } else {
                                                Bukkit.getServer().dispatchCommand(Bukkit.getConsoleSender(), type.trim() + " " + timeCalc(clicked, banCount) + " " + victim.trim() + " " + "--sender=" + staff.getPlayer().getName() + " " + reason);
                                            }
                                        }
                                    } else {
                                        String warn = Utility.getCore().getConfig().getString("warn-command");
                                        if (Utility.getCore().getConfig().getBoolean("use-staff-perms")) {
                                            if (type.contains("mute")) {
                                                if (muted) {
                                                    CyberDevAPI.send(staff, "&cThis user is already muted!");
                                                    return;
                                                }
                                                staff.chat("/" + typeCommand(warn.trim()) + " " + victim.trim() + " " + reason);
                                            } else {
                                                staff.chat("/" + typeCommand(warn.trim()) + " " + victim.trim() + " " + reason);
                                            }
                                        } else {
                                            if (type.contains("mute")) {
                                                if (muted) {
                                                    CyberDevAPI.send(staff, "&cThis user is already muted!");
                                                    return;
                                                }
                                                Bukkit.getServer().dispatchCommand(Bukkit.getConsoleSender(), warn.trim() + " " + victim.trim() + " " + "--sender=" + staff.getPlayer().getName() + " " + reason);
                                            } else {
                                                Bukkit.getServer().dispatchCommand(Bukkit.getConsoleSender(), warn.trim() + " " + victim.trim() + " " + "--sender=" + staff.getPlayer().getName() + " " + reason);
                                            }
                                        }
                                    }
                                } else {
                                    if (Utility.getCore().getConfig().getBoolean("use-staff-perms")) {
                                        if (type.contains("mute")) {
                                            if (muted) {
                                                CyberDevAPI.send(staff, "&cThis user is already muted!");
                                                return;
                                            }
                                            staff.chat("/" + typeCommand(type.trim()) + " " + victim.trim() + " " + timeCalc(clicked, muteCount) + " " + reason);
                                        } else {
                                            staff.chat("/" + typeCommand(type.trim()) + " " + victim.trim() + " " + timeCalc(clicked, banCount) + " " + reason);
                                        }
                                    } else {
                                        if (type.contains("mute")) {
                                            if (muted) {
                                                CyberDevAPI.send(staff, "&cThis user is already muted!");
                                                return;
                                            }
                                            Bukkit.getServer().dispatchCommand(Bukkit.getConsoleSender(), typeCommand(type.trim()) + " " + timeCalc(clicked, muteCount) + " " + victim.trim() + " " + "--sender=" + staff.getPlayer().getName() + " " + reason);
                                        } else {
                                            Bukkit.getServer().dispatchCommand(Bukkit.getConsoleSender(), typeCommand(type.trim()) + " " + timeCalc(clicked, banCount) + " " + victim.trim() + " " + "--sender=" + staff.getPlayer().getName() + " " + reason);
                                        }
                                    }
                                }

                            } catch (Exception err) {
                                Utility.consoleLog(err.getMessage());
                            }
                        }
                    }
                }

            }
        }.runTaskAsynchronously(Utility.getCore()).getTaskId();
    }

    private static String timeCalc(ItemStack clicked, int banCount) {
        banCount = banCount + 1;
        String originalTime = Utility.getCore().getConfig().getString("punishments." + clicked.getItemMeta().getDisplayName().toLowerCase().replace(CyberDevAPI.ChatColour(Utility.getCore().getConfig().getString("item-name-colour").trim()), "") + ".time." + "final");
        if (Utility.getCore().getConfig().isSet("punishments." + clicked.getItemMeta().getDisplayName().toLowerCase().replace(CyberDevAPI.ChatColour(Utility.getCore().getConfig().getString("item-name-colour").trim()), "") + ".time." + banCount)) {
            originalTime = Utility.getCore().getConfig().getString("punishments." + clicked.getItemMeta().getDisplayName().toLowerCase().replace(CyberDevAPI.ChatColour(Utility.getCore().getConfig().getString("item-name-colour").trim()), "") + ".time." + banCount);
            return originalTime;
        } else {
            if (Utility.getCore().getConfig().getBoolean("final-offense-perm-ban")) {
                return "";
            }
            return originalTime;
        }

    }

    private static String typeCommand(String type) {
        if (type.toLowerCase().equals("ban")) {
            type = Utility.getCore().getConfig().getString("ban-command");
        } else {
            if (type.toLowerCase().equals("tempban")) {
                type = Utility.getCore().getConfig().getString("tempban-command");
            } else {
                if (type.toLowerCase().equals("tempwarn")) {
                    type = Utility.getCore().getConfig().getString("tempwarn-command");
                } else {
                    if (type.toLowerCase().equals("warn")) {
                        type = Utility.getCore().getConfig().getString("warn-command");
                    } else {
                        if (type.toLowerCase().equals("tempmute")) {
                            type = Utility.getCore().getConfig().getString("tempmute-command");
                        } else {
                            if (type.toLowerCase().equals("mute")) {
                                type = Utility.getCore().getConfig().getString("mute-command");
                            }
                        }
                    }
                }
            }
        }
        return type.trim();
    }

}
