package dev.thecybercode.plugin.cyberpunish.bukkit.utils;

import com.sun.istack.internal.NotNull;
import dev.thecybercode.devapi.CyberDevAPI;
import dev.thecybercode.plugin.cyberpunish.bukkit.CyberPunishCore;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.plugin.PluginDescriptionFile;

public class Utility {
    private CyberPunishCore Core() {
        return (CyberPunishCore) CyberPunishCore.getPlugin((Class) CyberPunishCore.class);
    }

    public static PluginDescriptionFile descriptionFile() {
        return getCore().getDescription();
    }

    public static CyberPunishCore getCore() {
        return (CyberPunishCore)CyberPunishCore.getPlugin((Class)CyberPunishCore.class);
    }

    @NotNull
    public static String ChatColour(final String message) {
        if (getCore().getServer().getPluginManager().getPlugin("CyberDevAPI") != null) {
            final String chatColour = CyberDevAPI.ChatColour(message);
            if (chatColour == null) {
            }
            return chatColour;
        }
        final String translateAlternateColorCodes = ChatColor.translateAlternateColorCodes('&', message);
        if (translateAlternateColorCodes == null) {
        }
        return translateAlternateColorCodes;
    }

    public static void consoleLog(final String message) {
        if (getCore().getServer().getPluginManager().getPlugin("CyberDevAPI") != null) {
            Bukkit.getConsoleSender().sendMessage("[" + descriptionFile().getPrefix() + "] " + ChatColour("&3" + message));
        }
        else {
            Bukkit.getConsoleSender().sendMessage("[" + descriptionFile().getPrefix() + "] " + ChatColor.translateAlternateColorCodes('&', "&3" + message));
        }
    }
    public static void consoleError(final String message) {
        if (getCore().getServer().getPluginManager().getPlugin("CyberDevAPI") != null) {
            Bukkit.getLogger().severe("[" + descriptionFile().getPrefix() + "] " + ChatColour("&3" + message));
        }
        else {
            Bukkit.getLogger().severe("[" + descriptionFile().getPrefix() + "] " + ChatColor.translateAlternateColorCodes('&', "&3" + message));
        }
    }

}

