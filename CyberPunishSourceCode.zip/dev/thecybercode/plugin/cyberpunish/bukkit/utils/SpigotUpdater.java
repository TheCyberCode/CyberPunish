package dev.thecybercode.plugin.cyberpunish.bukkit.utils;

import org.bukkit.plugin.java.JavaPlugin;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

public class SpigotUpdater
{
    private int project;
    private URL checkURL;
    private String newVersion;
    private JavaPlugin plugin;

    public SpigotUpdater(final JavaPlugin plugin, final int projectID) {
        this.project = 0;
        this.newVersion = "";
        this.plugin = plugin;
        this.newVersion = plugin.getDescription().getVersion();
        this.project = projectID;
        try {
            this.checkURL = new URL("https://api.spigotmc.org/legacy/update.php?resource=" + getProjectID());
        }
        catch (MalformedURLException ex) {}
    }

    public int getProjectID() {
        return this.project;
    }

    public JavaPlugin getPlugin() {
        return Utility.getCore();
    }

    public String getLatestVersion() {
        return this.newVersion;
    }

    public String getResourceURL() {
        return "https://www.spigotmc.org/resources/" + this.project;
    }
    public String getUpdateURL() {
        return  getResourceURL()+"/updates";
    }

    public boolean checkForUpdates() {
        final URLConnection con;
        try {
            con = this.checkURL.openConnection();
            this.newVersion = new BufferedReader(new InputStreamReader(con.getInputStream())).readLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return !this.plugin.getDescription().getVersion().equals(this.newVersion);
    }
}
