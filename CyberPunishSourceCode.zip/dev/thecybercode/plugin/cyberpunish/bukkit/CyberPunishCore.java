package dev.thecybercode.plugin.cyberpunish.bukkit;

import dev.thecybercode.plugin.cyberpunish.bukkit.commands.CommandSetup;
import dev.thecybercode.plugin.cyberpunish.bukkit.configuration.ConfigManager;
import dev.thecybercode.plugin.cyberpunish.bukkit.events.EventManager;
import dev.thecybercode.plugin.cyberpunish.bukkit.utils.Metrics;
import dev.thecybercode.plugin.cyberpunish.bukkit.utils.Utility;
import org.bukkit.ChatColor;
import org.bukkit.plugin.PluginDescriptionFile;
import org.bukkit.plugin.java.JavaPlugin;

public class CyberPunishCore extends JavaPlugin {
    @Override
    public void onEnable() {
        super.onEnable();
        setupCode();
    }


    public void setupCode() {
        try {
            try {
                new ConfigManager();
                new CommandSetup();
                new EventManager();
                new Metrics(this);
            } catch (Exception e) {
                Utility.consoleError("OOF: " + ChatColor.RED + e.getStackTrace().toString());
            }
        } finally {
            final PluginDescriptionFile PDF = Utility.descriptionFile();
            Utility.consoleLog("&3&l-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-");
            Utility.consoleLog("&3&l                   " + PDF.getName());
            Utility.consoleLog("&3&l                Made by:&7 TheCyberCode");
            Utility.consoleLog("&3&l                   Version: &7" + PDF.getVersion().replace("[", "").replace("]", ""));
            Utility.consoleLog("&3&l                ");
            Utility.consoleLog("&3&l  Depends on: &7" + PDF.getDepend().toString().replace("[", "").replace("]", ""));
            Utility.consoleLog("&3&l  SoftDepends on: &7" + PDF.getSoftDepend().toString().replace("[", "").replace("]", ""));
            Utility.consoleLog("&3&l  Loads before: &7" + PDF.getLoadBefore().toString().replace("[", "").replace("]", ""));
            Utility.consoleLog("&3&l  Site: &7" + PDF.getWebsite().replace("[", "").replace("]", ""));
            Utility.consoleLog("&3&l-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-");
        }
    }

    @Override
    public void onDisable() {

    }

    @Override
    public void onLoad() {
        super.onLoad();
    }
}
