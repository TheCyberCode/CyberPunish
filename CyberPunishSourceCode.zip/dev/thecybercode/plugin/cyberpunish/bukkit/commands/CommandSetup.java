package dev.thecybercode.plugin.cyberpunish.bukkit.commands;


import dev.thecybercode.plugin.cyberpunish.bukkit.utils.Utility;

public class CommandSetup {
    public CommandSetup() {
        Utility.getCore().getCommand("punisher").setExecutor(new PunishInitCommand());
    }
}
