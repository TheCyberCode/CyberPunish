package dev.thecybercode.plugin.cyberpunish.bukkit.commands;

import dev.thecybercode.devapi.CyberDevAPI;
import dev.thecybercode.plugin.cyberpunish.bukkit.database.userBanData;
import dev.thecybercode.plugin.cyberpunish.bukkit.menus.PunishTypeMenu;
import dev.thecybercode.plugin.cyberpunish.bukkit.utils.Utility;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class PunishInitCommand implements CommandExecutor {
    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (sender instanceof Player) {
            Player user = (Player) sender;
            if(!sender.hasPermission(Utility.getCore().getConfig().getString("permission").toLowerCase())){
                sender.sendMessage(CyberDevAPI.ChatColour("&cYou must be staff or higher to do that!"));
                return true;
            }
            if (args.length > 0) {
                if (Bukkit.getOfflinePlayer(args[0].toLowerCase().trim()).getUniqueId() != null) {
                    //   CyberDevAPI.send(user, Bukkit.getOfflinePlayer(args[0].toLowerCase().trim()).getName());
                    if (Bukkit.getOfflinePlayer(args[0].toLowerCase().trim()).hasPlayedBefore() == true) {
                        userBanData.setUserToBan(user, Bukkit.getOfflinePlayer(args[0]).getUniqueId());
                        user.openInventory(PunishTypeMenu.typeMenu);
                        CyberDevAPI.send(user, "&6Punishing user: &r" + Bukkit.getOfflinePlayer(args[0].toLowerCase().trim()).getName());
                    } else {
                        CyberDevAPI.send(user, "&c" + args[0].toLowerCase().trim() + "&c, " + "&ccould not be found.");
                    }
                    return true;
                } else {
                    CyberDevAPI.send(user, "&c" + args[0].toLowerCase().trim() + "&c, " + "&ccould not be found.");
                    return true;
                }
            } else {
                CyberDevAPI.send(user, "&cPlease specify a user to punish.");
                return true;
            }
        }
        return false;
    }
}
