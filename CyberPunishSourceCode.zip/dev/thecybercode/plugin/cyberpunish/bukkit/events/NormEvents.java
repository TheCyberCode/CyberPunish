package dev.thecybercode.plugin.cyberpunish.bukkit.events;

import dev.thecybercode.plugin.cyberpunish.bukkit.utils.Utility;
import litebans.api.Database;
import litebans.api.Entry;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.scheduler.BukkitRunnable;

public class NormEvents implements Listener {

    @EventHandler
    public void join(PlayerJoinEvent e){
        if(true == true){
            return;
        }
        final Player user = e.getPlayer();
        new BukkitRunnable() {
            /**
             * When an object implementing interface <code>Runnable</code> is used
             * to create a thread, starting the thread causes the object's
             * <code>run</code> method to be called in that separately executing
             * thread.
             * <p>
             * The general contract of the method <code>run</code> is that it may
             * take any action whatsoever.
             *
             * @see Thread#run()
             */
            @Override
            public void run() {
                boolean banned = Database.get().isPlayerBanned(user.getUniqueId(), user.getAddress().getHostName());
                if(banned){
                    user.sendMessage("You are banned?");
                    return;
                } else{
                    user.sendMessage("You are not banned?");
                    return;
                }
            }
        }.runTaskLaterAsynchronously(Utility.getCore(), 60);
    }
}
