package dev.thecybercode.plugin.cyberpunish.bukkit.events;

import dev.thecybercode.devapi.CyberDevAPI;
import dev.thecybercode.plugin.cyberpunish.bukkit.menus.*;
import dev.thecybercode.plugin.cyberpunish.bukkit.utils.PunishLayout;
import dev.thecybercode.plugin.cyberpunish.bukkit.utils.Utility;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

public class GUIEvents implements Listener {

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        Player player = (Player) event.getWhoClicked(); // The player that clicked the item
        ItemStack clicked = event.getCurrentItem(); // The item that was clicked
        Inventory inventory = event.getInventory(); // The inventory that was clicked in
        if (inventory.getName().equals(PunishTypeMenu.typeMenu.getName()) || inventory.getName().equals(PVPMenu.pvpMenu.getName()) || inventory.getName().equals(MovementMenu.punishTypeMenu.getName()) || inventory.getName().equals(ChatMenu.punishTypeMenu.getName())|| inventory.getName().equals(OtherHacksMenu.punishTypeMenu.getName())|| inventory.getName().equals(OtherMenu.punishTypeMenu.getName())|| inventory.getName().equals(ExploitMenu.punishTypeMenu.getName())|| inventory.getName().equals(AutoMenu.punishTypeMenu.getName())|| inventory.getName().equals(CustomMenu.punishTypeMenu.getName())) {
            if (inventory == null || clicked == null) {
                return;
            }
            ///event.setCancelled(true);
            if (clicked.getType() == Material.AIR) {
                event.setCancelled(true);
                return;
            }
            if(clicked.getItemMeta().getDisplayName() == null){
                return;
            }
            if (clicked.getItemMeta().getDisplayName().equalsIgnoreCase(CyberDevAPI.ChatColour("&6PVP"))) {
                //player.closeInventory();
                event.setCancelled(true);
                player.openInventory(PVPMenu.pvpMenu);
                return;
            }
            if (clicked.getItemMeta().getDisplayName().equalsIgnoreCase(CyberDevAPI.ChatColour("&6MOVEMENT"))) {
                //player.closeInventory();
                event.setCancelled(true);
                player.openInventory(MovementMenu.punishTypeMenu);
                return;
            }
            if (clicked.getItemMeta().getDisplayName().equalsIgnoreCase(CyberDevAPI.ChatColour("&6AUTO HACKS"))) {
                //player.closeInventory();
                event.setCancelled(true);
                player.openInventory(AutoMenu.punishTypeMenu);
                return;
            }
            if (clicked.getItemMeta().getDisplayName().equalsIgnoreCase(CyberDevAPI.ChatColour("&6OTHER HACKS"))) {
                //player.closeInventory();
                event.setCancelled(true);
                player.openInventory(OtherHacksMenu.punishTypeMenu);
                return;
            }
            if (clicked.getItemMeta().getDisplayName().equalsIgnoreCase(CyberDevAPI.ChatColour("&6EXPLOITING"))) {
                //player.closeInventory();
                event.setCancelled(true);
                player.openInventory(ExploitMenu.punishTypeMenu);
                return;
            }
            if (clicked.getItemMeta().getDisplayName().equalsIgnoreCase(CyberDevAPI.ChatColour("&6OTHER"))) {
                //player.closeInventory();
                event.setCancelled(true);
                player.openInventory(OtherMenu.punishTypeMenu);
                return;
            }
            if (clicked.getItemMeta().getDisplayName().equalsIgnoreCase(CyberDevAPI.ChatColour("&6CHAT"))) {
                //player.closeInventory();
                event.setCancelled(true);
                player.openInventory(ChatMenu.punishTypeMenu);
                return;
            }
            if (clicked.getItemMeta().getDisplayName().equalsIgnoreCase(CyberDevAPI.ChatColour("&6CUSTOM"))) {
                //player.closeInventory();
                event.setCancelled(true);
                player.openInventory(CustomMenu.punishTypeMenu);
                return;
            }
            if (inventory.getName() == PVPMenu.pvpMenu.getName()) {
                ///     player.sendMessage("pvpmenu");
                if (clicked != null) {
                    event.setCancelled(true);
                    if (Utility.getCore().getConfig().getString("punishments." + clicked.getItemMeta().getDisplayName().toLowerCase().replace(CyberDevAPI.ChatColour(Utility.getCore().getConfig().getString("item-name-colour").trim()), "") + ".reason") != null) {
                        //        CyberDevAPI.send(player, "Name: " + clicked.getItemMeta().getDisplayName().toLowerCase().replace(CyberDevAPI.ChatColour(Utility.getCore().getConfig().getString("item-name-colour").trim()), ""));
//                        CyberDevAPI.send(player, "&3Username: " + Bukkit.getOfflinePlayer(userBanData.getUUIDToBan(player)).getName());
//                        CyberDevAPI.send(player, "&3Punishment Name: " + CyberDevAPI.ChatColour(clicked.getItemMeta().getDisplayName().toLowerCase().replace(CyberDevAPI.ChatColour(Utility.getCore().getConfig().getString("item-name-colour").trim()), "")));
//                        CyberDevAPI.send(player, "&3Reason: " + CyberDevAPI.ChatColour(Utility.getCore().getConfig().getString("punishments." + clicked.getItemMeta().getDisplayName().toLowerCase().replace(CyberDevAPI.ChatColour(Utility.getCore().getConfig().getString("item-name-colour").trim()), "") + ".reason")));
//                        CyberDevAPI.send(player, "&3Type: " + Utility.getCore().getConfig().getString("punishments." + clicked.getItemMeta().getDisplayName().toLowerCase().replace(CyberDevAPI.ChatColour(Utility.getCore().getConfig().getString("item-name-colour").trim()), "") + ".type"));
//                        CyberDevAPI.send(player, "&3Time: " + Utility.getCore().getConfig().getString("punishments." + clicked.getItemMeta().getDisplayName().toLowerCase().replace(CyberDevAPI.ChatColour(Utility.getCore().getConfig().getString("item-name-colour").trim()), "") + ".time"));
                        CyberDevAPI.send(player, "\n");
                        try {
                            PunishLayout.punishUser(player, clicked);
                            player.closeInventory();
                        } catch (Exception err) {
                            Utility.consoleLog(err.getMessage());
                        }
                    }
                }
            }
            if (inventory.getName() == MovementMenu.punishTypeMenu.getName()) {
                ///     player.sendMessage("pvpmenu");
                if (clicked != null) {
                    event.setCancelled(true);
                    if (Utility.getCore().getConfig().getString("punishments." + clicked.getItemMeta().getDisplayName().toLowerCase().replace(CyberDevAPI.ChatColour(Utility.getCore().getConfig().getString("item-name-colour").trim()), "") + ".reason") != null) {
                        CyberDevAPI.send(player, "\n");
                        try {
                            PunishLayout.punishUser(player, clicked);
                            player.closeInventory();
                        } catch (Exception err) {
                            Utility.consoleLog(err.getMessage());
                        }
                    }
                }
            }
            if (inventory.getName() == CustomMenu.punishTypeMenu.getName()) {
                ///     player.sendMessage("pvpmenu");
                if (clicked != null) {
                    event.setCancelled(true);
                    if (Utility.getCore().getConfig().getString("punishments." + clicked.getItemMeta().getDisplayName().toLowerCase().replace(CyberDevAPI.ChatColour(Utility.getCore().getConfig().getString("item-name-colour").trim()), "") + ".reason") != null) {
                        CyberDevAPI.send(player, "\n");
                        try {
                            PunishLayout.punishUser(player, clicked);
                            player.closeInventory();
                        } catch (Exception err) {
                            Utility.consoleLog(err.getMessage());
                        }
                    }
                }
            }
            if (inventory.getName() == ChatMenu.punishTypeMenu.getName()) {
                ///     player.sendMessage("pvpmenu");
                if (clicked != null) {
                    event.setCancelled(true);
                    if (Utility.getCore().getConfig().getString("punishments." + clicked.getItemMeta().getDisplayName().toLowerCase().replace(CyberDevAPI.ChatColour(Utility.getCore().getConfig().getString("item-name-colour").trim()), "") + ".reason") != null) {
                        CyberDevAPI.send(player, "\n");
                        try {
                            PunishLayout.punishUser(player, clicked);
                            player.closeInventory();
                        } catch (Exception err) {
                            Utility.consoleLog(err.getMessage());
                        }
                    }
                }
            }
            if (inventory.getName() == ExploitMenu.punishTypeMenu.getName()) {
                ///     player.sendMessage("pvpmenu");
                if (clicked != null) {
                    event.setCancelled(true);
                    if (Utility.getCore().getConfig().getString("punishments." + clicked.getItemMeta().getDisplayName().toLowerCase().replace(CyberDevAPI.ChatColour(Utility.getCore().getConfig().getString("item-name-colour").trim()), "") + ".reason") != null) {
                        CyberDevAPI.send(player, "\n");
                        try {
                            PunishLayout.punishUser(player, clicked);
                            player.closeInventory();
                        } catch (Exception err) {
                            Utility.consoleLog(err.getMessage());
                        }
                    }
                }
            }
            if (inventory.getName() == OtherMenu.punishTypeMenu.getName()) {
                ///     player.sendMessage("pvpmenu");
                if (clicked != null) {
                    event.setCancelled(true);
                    if (Utility.getCore().getConfig().getString("punishments." + clicked.getItemMeta().getDisplayName().toLowerCase().replace(CyberDevAPI.ChatColour(Utility.getCore().getConfig().getString("item-name-colour").trim()), "") + ".reason") != null) {
                        CyberDevAPI.send(player, "\n");
                        try {
                            PunishLayout.punishUser(player, clicked);
                            player.closeInventory();
                        } catch (Exception err) {
                            Utility.consoleLog(err.getMessage());
                        }
                    }
                }
            }
            if (inventory.getName() == OtherHacksMenu.punishTypeMenu.getName()) {
                ///     player.sendMessage("pvpmenu");
                if (clicked != null) {
                    event.setCancelled(true);
                    if (Utility.getCore().getConfig().getString("punishments." + clicked.getItemMeta().getDisplayName().toLowerCase().replace(CyberDevAPI.ChatColour(Utility.getCore().getConfig().getString("item-name-colour").trim()), "") + ".reason") != null) {
                        CyberDevAPI.send(player, "\n");
                        try {
                            PunishLayout.punishUser(player, clicked);
                            player.closeInventory();
                        } catch (Exception err) {
                            Utility.consoleLog(err.getMessage());
                        }
                    }
                }
            }
            event.setCancelled(true);
        }
    }
}
