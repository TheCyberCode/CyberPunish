package dev.thecybercode.plugin.cyberpunish.bukkit.events;

import dev.thecybercode.plugin.cyberpunish.bukkit.database.PunishTypes;
import dev.thecybercode.plugin.cyberpunish.bukkit.utils.Utility;
import litebans.api.Events;


public class EventManager {
    public EventManager() {
        Utility.getCore().getServer().getPluginManager().registerEvents(new NormEvents(), Utility.getCore());
        Utility.getCore().getServer().getPluginManager().registerEvents(new GUIEvents(), Utility.getCore());
        Utility.getCore().getServer().getPluginManager().registerEvents(new OtherEvents(), Utility.getCore());
        Utility.getCore().getServer().getPluginManager().registerEvents(new PunishEvents(), Utility.getCore());
    }
}
