package dev.thecybercode.plugin.cyberpunish.bukkit.events;

import dev.thecybercode.plugin.cyberpunish.bukkit.database.PunishTypes;
import org.bukkit.event.Listener;

public class PunishEvents implements Listener {

}
