package dev.thecybercode.plugin.cyberpunish.bukkit.events;

import dev.thecybercode.devapi.CyberDevAPI;
import dev.thecybercode.plugin.cyberpunish.bukkit.utils.SpigotUpdater;
import dev.thecybercode.plugin.cyberpunish.bukkit.utils.Utility;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.PluginDescriptionFile;

public class OtherEvents implements Listener {
    @EventHandler
    public void onPlayerJoin(final PlayerJoinEvent event) {
        final Player player = event.getPlayer();
        if (player.isOp()) {
            final SpigotUpdater updater = new SpigotUpdater(Utility.getCore(), 65745);
            try {
                final PluginDescriptionFile PDF = Utility.getCore().getDescription();
                if (updater.checkForUpdates()) {
                    CyberDevAPI.send(event.getPlayer(),"&8&l(&4&l!&8&l)&7 " + PDF.getFullName() + " Update Required!\n&8&l(&4&l!&8&l)&r &7Link: &b" + updater.getUpdateURL() +"\n&8&l(&4&l!&8&l)&r &7Latest Version: &6" + updater.getLatestVersion() + "\n&8&l(&4&l!&8&l)&r&7 Current Version: &6" + PDF.getVersion());
                }
            } catch (Exception e) {
                Bukkit.getLogger().info("ERROR: Could not check for updates!");
            }
        }
    }
}
