package dev.thecybercode.plugin.cyberpunish.bukkit.menus;

import dev.thecybercode.devapi.CyberDevAPI;
import dev.thecybercode.plugin.cyberpunish.bukkit.database.PunishTypes;
import dev.thecybercode.plugin.cyberpunish.bukkit.utils.Utility;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;

public class PunishTypeMenu {
    public static Inventory typeMenu = Bukkit.createInventory(null, 18, CyberDevAPI.ChatColour("&cPUNISH"));
    static {
        try {
            createDisplay(Material.getMaterial(Utility.getCore().getConfig().getString("mat-pvp").toUpperCase().trim()), typeMenu, Utility.getCore().getConfig().getInt("slot-pvp"), "&6PVP", "&lPVP Punishments", null,null,null);
            createDisplay(Material.getMaterial(Utility.getCore().getConfig().getString("mat-chat").toUpperCase().trim()), typeMenu, Utility.getCore().getConfig().getInt("slot-chat"), "&6CHAT", "&lChat Punishments", null,null,null);
            createDisplay(Material.getMaterial(Utility.getCore().getConfig().getString("mat-move").toUpperCase().trim()), typeMenu, Utility.getCore().getConfig().getInt("slot-move"), "&6MOVEMENT", "&lMovement Punishments", null,null,null);
            createDisplay(Material.getMaterial(Utility.getCore().getConfig().getString("mat-auto").toUpperCase().trim()), typeMenu, Utility.getCore().getConfig().getInt("slot-auto"), "&6AUTO HACKS", "&lAuto Hacks Punishments", null,null,null);
            createDisplay(Material.getMaterial(Utility.getCore().getConfig().getString("mat-other-hacks").toUpperCase().trim()), typeMenu, Utility.getCore().getConfig().getInt("slot-other-hacks"), "&6OTHER HACKS", "&lOther Hacks Punishments", null,null,null);
            createDisplay(Material.getMaterial(Utility.getCore().getConfig().getString("mat-exploit").toUpperCase().trim()), typeMenu, Utility.getCore().getConfig().getInt("slot-exploit"), "&6EXPLOITING", "&lExploiting Punishments", null,null,null);
            createDisplay(Material.getMaterial(Utility.getCore().getConfig().getString("mat-other").toUpperCase().trim()), typeMenu, Utility.getCore().getConfig().getInt("slot-other"), "&6OTHER", "&lOther Punishments", null,null,null);
            createDisplay(Material.getMaterial(Utility.getCore().getConfig().getString("mat-custom").toUpperCase().trim()), typeMenu, Utility.getCore().getConfig().getInt("slot-custom"), "&6CUSTOM", "&lOther Punishments", null,null,null);
        } catch (Exception err){
            Utility.consoleLog(err.getMessage());
        }
    }
    public static void createDisplay(Material material, Inventory inv, int Slot, String name, String lore, String lore2, String lore3, String lore4) {
        try {
            ItemStack item = new ItemStack(material);
            ItemMeta meta = item.getItemMeta();
            meta.setDisplayName(CyberDevAPI.ChatColour(name));
            ArrayList<String> Lore = new ArrayList<String>();
            Lore.add(CyberDevAPI.ChatColour(lore));
            if (lore2 != null) {
                Lore.add(CyberDevAPI.ChatColour(lore2));
            }
            if (lore3 != null) {
                Lore.add(CyberDevAPI.ChatColour(lore3));
            }
            if (lore4 != null) {
                Lore.add(CyberDevAPI.ChatColour(lore4));
            }
            if(Lore != null) {
                meta.setLore(Lore);
            }
            if(meta != null) {
                item.setItemMeta(meta);
            }
            if(item != null) {
                inv.setItem(Slot, item);
            }

        } finally {
            return;
        }
    }
}
