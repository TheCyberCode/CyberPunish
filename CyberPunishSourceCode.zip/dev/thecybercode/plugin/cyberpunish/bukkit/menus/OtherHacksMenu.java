package dev.thecybercode.plugin.cyberpunish.bukkit.menus;

import dev.thecybercode.devapi.CyberDevAPI;
import dev.thecybercode.plugin.cyberpunish.bukkit.database.PunishTypes;
import dev.thecybercode.plugin.cyberpunish.bukkit.utils.Utility;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;

public class OtherHacksMenu {
    public static Inventory punishTypeMenu = Bukkit.createInventory(null, 54, CyberDevAPI.ChatColour("&cPUNISH"));

    static {
        int i = 0;
        for (PunishTypes.OTHERHACKS punish : PunishTypes.OTHERHACKS.values()) {
            if (i > 56) {
                break;
            } else {
                String perm = null;
                if(Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".permission")) {
                    perm = Utility.getCore().getConfig().getString("punishments." + punish.name().toLowerCase() + ".permission");
                }
                createDisplay(Material.getMaterial(Utility.getCore().getConfig().getString("punishments." + punish.name().toLowerCase() + ".material").toUpperCase()), punishTypeMenu, i, CyberDevAPI.ChatColour(Utility.getCore().getConfig().getString("item-name-colour").trim()) + punish.name(), "&8Type: &r" + Utility.getCore().getConfig().getString("punishments." + punish.name().toLowerCase() + ".type").trim() + "", "&8Reason: &r" + Utility.getCore().getConfig().getString("punishments." + punish.name().toLowerCase() + ".reason"), CyberDevAPI.ChatColour(Utility.getCore().getConfig().getString("item-name-colour").trim()) +"&8Duration:&r " + "&r" + Utility.getCore().getConfig().getString("punishments." + punish.name().toLowerCase() + ".time.1"), perm);
                i++;
            }
        }

    }

    public static void createDisplay(Material material, Inventory inv, int Slot, String name, String lore, String lore2, String lore3, String lore4) {
        try {
            ItemStack item = new ItemStack(material);
            ItemMeta meta = item.getItemMeta();
            meta.setDisplayName(CyberDevAPI.ChatColour(name));
            ArrayList<String> Lore = new ArrayList<String>();
            Lore.add(CyberDevAPI.ChatColour(lore));
            if (lore2 != null) {
                Lore.add(CyberDevAPI.ChatColour(lore2));
            }
            if (lore3 != null) {
                Lore.add(CyberDevAPI.ChatColour(lore3));
            }
            if (lore4 != null) {
                Lore.add(CyberDevAPI.ChatColour(lore4));
            }
            meta.setLore(Lore);
            item.setItemMeta(meta);

            inv.setItem(Slot, item);

        } finally {
            return;
        }
    }
}
