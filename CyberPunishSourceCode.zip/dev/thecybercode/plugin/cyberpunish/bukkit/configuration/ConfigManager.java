package dev.thecybercode.plugin.cyberpunish.bukkit.configuration;

import dev.thecybercode.plugin.cyberpunish.bukkit.database.PunishTypes;
import dev.thecybercode.plugin.cyberpunish.bukkit.utils.Utility;
import org.bukkit.plugin.PluginDescriptionFile;

import java.util.ArrayList;
import java.util.List;

public class ConfigManager {
    public ConfigManager() {
        final PluginDescriptionFile PDF = Utility.descriptionFile();
        final String logPrefix = "[" + PDF.getPrefix() + "] ";
        Utility.getCore().getServer().getConsoleSender().sendMessage(logPrefix + "Copying Defaults");
        Utility.getCore().getConfig().options().copyDefaults(true);
        Utility.getCore().saveConfig();
        Utility.getCore().getConfig().set("Plugin-Ver", PDF.getVersion());
        Utility.getCore().getServer().getConsoleSender().sendMessage(logPrefix + "Saving Defaults!");
        for(PunishTypes.AUTO punish : PunishTypes.AUTO.values()){
            if(Utility.getCore().getConfig().isConfigurationSection("punishments."+punish.name().toLowerCase())){
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".reason")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".reason", punish.name().toLowerCase().replace("_", " "));
                }
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".time")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".time", "7d");
                }
                /////// Layered Offenses START /////
                try {
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.1")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.1", "7d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.2")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.2", "14d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.3")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.3", "30d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.4")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.4", "60d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.final")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.final", "90d");
                    }
                } catch (Exception err){
                    Utility.consoleLog(err.getMessage());
                }
                /////// Layered Offenses END /////
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".type")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".type", "tempban");
                }
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".material")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".material", "book");
                }
            } else {
                Utility.getCore().getConfig().createSection("punishments."+punish.name().toLowerCase());
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".reason")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".reason", punish.name().toLowerCase().replace("_", " "));
                }
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".time")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".time", "7d");
                }
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".type")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".type", "tempban");
                }
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".material")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".material", "book");
                }
                /////// Layered Offenses START /////
                try {
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.1")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.1", "7d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.2")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.2", "14d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.3")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.3", "30d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.4")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.4", "60d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.final")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.final", "90d");
                    }
                } catch (Exception err){
                    Utility.consoleLog(err.getMessage());
                }
                /////// Layered Offenses END /////
            }
        }
        for(PunishTypes.OTHER_PUNISH punish : PunishTypes.OTHER_PUNISH.values()){
            if(Utility.getCore().getConfig().isConfigurationSection("punishments."+punish.name().toLowerCase())){
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".reason")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".reason", punish.name().toLowerCase().replace("_", " "));
                }
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".time")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".time", "7d");
                }
                /////// Layered Offenses START /////
                try {
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.1")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.1", "7d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.2")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.2", "14d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.3")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.3", "30d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.4")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.4", "60d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.final")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.final", "90d");
                    }
                } catch (Exception err){
                    Utility.consoleLog(err.getMessage());
                }
                /////// Layered Offenses END /////
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".type")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".type", "tempban");
                }
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".material")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".material", "book");
                }
            } else {
                Utility.getCore().getConfig().createSection("punishments."+punish.name().toLowerCase());
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".reason")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".reason", punish.name().toLowerCase().replace("_", " "));
                }
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".time")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".time", "7d");
                }
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".type")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".type", "tempban");
                }
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".material")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".material", "book");
                }
                /////// Layered Offenses START /////
                try {
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.1")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.1", "7d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.2")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.2", "14d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.3")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.3", "30d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.4")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.4", "60d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.final")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.final", "90d");
                    }
                } catch (Exception err){
                    Utility.consoleLog(err.getMessage());
                }
                /////// Layered Offenses END /////
            }
        }
        for(PunishTypes.MOVEMENT punish : PunishTypes.MOVEMENT.values()){
            if(Utility.getCore().getConfig().isConfigurationSection("punishments."+punish.name().toLowerCase())){
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".reason")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".reason", punish.name().toLowerCase().replace("_", " "));
                }
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".time")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".time", "7d");
                }
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".type")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".type", "tempban");
                }
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".material")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".material", "book");
                }
                /////// Layered Offenses START /////
                try {
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.1")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.1", "7d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.2")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.2", "14d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.3")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.3", "30d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.4")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.4", "60d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.final")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.final", "90d");
                    }
                } catch (Exception err){
                    Utility.consoleLog(err.getMessage());
                }
                /////// Layered Offenses END /////
            } else {
                Utility.getCore().getConfig().createSection("punishments."+punish.name().toLowerCase());
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".reason")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".reason", punish.name().toLowerCase().replace("_", " "));
                }
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".time")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".time", "7d");
                }
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".type")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".type", "tempban");
                }
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".material")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".material", "book");
                }
                /////// Layered Offenses START /////
                try {
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.1")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.1", "7d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.2")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.2", "14d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.3")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.3", "30d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.4")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.4", "60d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.final")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.final", "90d");
                    }
                } catch (Exception err){
                    Utility.consoleLog(err.getMessage());
                }
                /////// Layered Offenses END /////
            }
        }
        for(PunishTypes.PVP punish : PunishTypes.PVP.values()){
            if(Utility.getCore().getConfig().isConfigurationSection("punishments."+punish.name().toLowerCase())){
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".reason")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".reason", punish.name().toLowerCase().replace("_", " "));
                }
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".time")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".time", "30d");
                }
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".type")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".type", "tempban");
                }
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".material")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".material", "book");
                }
                /////// Layered Offenses START /////
                try {
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.1")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.1", "7d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.2")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.2", "14d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.3")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.3", "30d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.4")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.4", "60d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.final")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.final", "90d");
                    }
                } catch (Exception err){
                    Utility.consoleLog(err.getMessage());
                }
                /////// Layered Offenses END /////
            } else {
                Utility.getCore().getConfig().createSection("punishments."+punish.name().toLowerCase());
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".reason")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".reason", punish.name().toLowerCase().replace("_", " "));
                }
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".time")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".time", "30d");
                }
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".type")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".type", "tempban");
                }
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".material")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".material", "book");
                }
                /////// Layered Offenses START /////
                try {
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.1")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.1", "7d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.2")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.2", "14d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.3")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.3", "30d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.4")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.4", "60d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.final")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.final", "90d");
                    }
                } catch (Exception err){
                    Utility.consoleLog(err.getMessage());
                }
                /////// Layered Offenses END /////
            }
        }
        for(PunishTypes.AURA punish : PunishTypes.AURA.values()){
            if(Utility.getCore().getConfig().isConfigurationSection("punishments."+punish.name().toLowerCase())){
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".reason")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".reason", punish.name().toLowerCase().replace("_", " "));
                }
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".time")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".time", "30d");
                }
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".type")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".type", "tempban");
                }
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".material")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".material", "book");
                }
                /////// Layered Offenses START /////
                try {
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.1")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.1", "7d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.2")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.2", "14d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.3")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.3", "30d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.4")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.4", "60d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.final")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.final", "90d");
                    }
                } catch (Exception err){
                    Utility.consoleLog(err.getMessage());
                }
                /////// Layered Offenses END /////
            } else {
                Utility.getCore().getConfig().createSection("punishments."+punish.name().toLowerCase());
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".reason")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".reason", punish.name().toLowerCase().replace("_", " "));
                }
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".time")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".time", "30d");
                }
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".type")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".type", "tempban");
                }
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".material")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".material", "book");
                }
                /////// Layered Offenses START /////
                try {
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.1")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.1", "7d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.2")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.2", "14d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.3")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.3", "30d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.4")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.4", "60d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.final")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.final", "90d");
                    }
                } catch (Exception err){
                    Utility.consoleLog(err.getMessage());
                }
                /////// Layered Offenses END /////
            }
        }
        for(String punish : Utility.getCore().getConfig().getStringList("custom-menu")){
            punish = punish.replaceAll(" ", "_");
            if(Utility.getCore().getConfig().isConfigurationSection("punishments."+punish.toLowerCase())){
                if(Utility.getCore().getConfig().isSet("punishments."+punish.toLowerCase() + ".reason")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.toLowerCase() + ".reason", punish.toLowerCase().replace("_", " "));
                }
                if(Utility.getCore().getConfig().isSet("punishments."+punish.toLowerCase() + ".time")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.toLowerCase() + ".time", "7d");
                }
                /////// Layered Offenses START /////
                try {
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.toLowerCase() + ".time.1")) {
                        Utility.getCore().getConfig().set("punishments." + punish.toLowerCase() + ".time.1", "7d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.toLowerCase() + ".time.2")) {
                        Utility.getCore().getConfig().set("punishments." + punish.toLowerCase() + ".time.2", "14d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.toLowerCase() + ".time.3")) {
                        Utility.getCore().getConfig().set("punishments." + punish.toLowerCase() + ".time.3", "30d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.toLowerCase() + ".time.4")) {
                        Utility.getCore().getConfig().set("punishments." + punish.toLowerCase() + ".time.4", "60d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.toLowerCase() + ".time.final")) {
                        Utility.getCore().getConfig().set("punishments." + punish.toLowerCase() + ".time.final", "90d");
                    }
                } catch (Exception err){
                    Utility.consoleLog(err.getMessage());
                }
                /////// Layered Offenses END /////
                if(Utility.getCore().getConfig().isSet("punishments."+punish.toLowerCase() + ".type")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.toLowerCase() + ".type", "tempban");
                }
                if(Utility.getCore().getConfig().isSet("punishments."+punish.toLowerCase() + ".material")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.toLowerCase() + ".material", "book");
                }
            } else {
                Utility.getCore().getConfig().createSection("punishments."+punish.toLowerCase());
                if(Utility.getCore().getConfig().isSet("punishments."+punish.toLowerCase() + ".reason")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.toLowerCase() + ".reason", punish.toLowerCase().replace("_", " "));
                }
                if(Utility.getCore().getConfig().isSet("punishments."+punish.toLowerCase() + ".time")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.toLowerCase() + ".time", "7d");
                }
                if(Utility.getCore().getConfig().isSet("punishments."+punish.toLowerCase() + ".type")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.toLowerCase() + ".type", "tempban");
                }
                if(Utility.getCore().getConfig().isSet("punishments."+punish.toLowerCase() + ".material")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.toLowerCase() + ".material", "book");
                }
                /////// Layered Offenses START /////
                try {
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.toLowerCase() + ".time.1")) {
                        Utility.getCore().getConfig().set("punishments." + punish.toLowerCase() + ".time.1", "7d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.toLowerCase() + ".time.2")) {
                        Utility.getCore().getConfig().set("punishments." + punish.toLowerCase() + ".time.2", "14d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.toLowerCase() + ".time.3")) {
                        Utility.getCore().getConfig().set("punishments." + punish.toLowerCase() + ".time.3", "30d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.toLowerCase() + ".time.4")) {
                        Utility.getCore().getConfig().set("punishments." + punish.toLowerCase() + ".time.4", "60d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.toLowerCase() + ".time.final")) {
                        Utility.getCore().getConfig().set("punishments." + punish.toLowerCase() + ".time.final", "90d");
                    }
                } catch (Exception err){
                    Utility.consoleLog(err.getMessage());
                }
                /////// Layered Offenses END /////
            }
        }
        for(PunishTypes.EXPLOIT punish : PunishTypes.EXPLOIT.values()){
            if(Utility.getCore().getConfig().isConfigurationSection("punishments."+punish.name().toLowerCase())){
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".reason")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".reason", punish.name().toLowerCase().replace("_", " "));
                }
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".time")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".time", "7d");
                }
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".type")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".type", "tempban");
                }
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".material")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".material", "book");
                }
                /////// Layered Offenses START /////
                try {
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.1")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.1", "7d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.2")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.2", "14d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.3")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.3", "30d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.4")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.4", "60d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.final")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.final", "90d");
                    }
                } catch (Exception err){
                    Utility.consoleLog(err.getMessage());
                }
                /////// Layered Offenses END /////
            } else {
                Utility.getCore().getConfig().createSection("punishments."+punish.name().toLowerCase());
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".reason")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".reason", punish.name().toLowerCase().replace("_", " "));
                }
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".time")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".time", "7d");
                }
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".type")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".type", "tempban");
                }
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".material")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".material", "book");
                }
                /////// Layered Offenses START /////
                try {
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.1")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.1", "7d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.2")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.2", "14d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.3")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.3", "30d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.4")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.4", "60d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.final")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.final", "90d");
                    }
                } catch (Exception err){
                    Utility.consoleLog(err.getMessage());
                }
                /////// Layered Offenses END /////
            }
        }
        for(PunishTypes.CHAT punish : PunishTypes.CHAT.values()){
            if(Utility.getCore().getConfig().isConfigurationSection("punishments."+punish.name().toLowerCase())){
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".reason")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".reason", punish.name().toLowerCase().replace("_", " "));
                }
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".time")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".time", "7d");
                }
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".type")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".type", "mute");
                }
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".material")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".material", "book");
                }
                /////// Layered Offenses START /////
                try {
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.1")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.1", "7d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.2")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.2", "14d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.3")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.3", "30d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.4")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.4", "60d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.final")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.final", "90d");
                    }
                } catch (Exception err){
                    Utility.consoleLog(err.getMessage());
                }
                /////// Layered Offenses END /////
            } else {
                Utility.getCore().getConfig().createSection("punishments."+punish.name().toLowerCase());
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".reason")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".reason", punish.name().toLowerCase().replace("_", " "));
                }
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".time")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".time", "7d");
                }
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".type")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".type", "mute");
                }
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".material")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".material", "book");
                }
                /////// Layered Offenses START /////
                try {
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.1")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.1", "7d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.2")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.2", "14d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.3")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.3", "30d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.4")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.4", "60d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.final")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.final", "90d");
                    }
                } catch (Exception err){
                    Utility.consoleLog(err.getMessage());
                }
                /////// Layered Offenses END /////
            }

        }
        for(PunishTypes.OTHERHACKS punish : PunishTypes.OTHERHACKS.values()){
            if(Utility.getCore().getConfig().isConfigurationSection("punishments."+punish.name().toLowerCase())){
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".reason")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".reason", punish.name().toLowerCase().replace("_", " "));
                }
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".time")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".time", "7d");
                }
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".type")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".type", "tempban");
                }
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".material")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".material", "book");
                }
                /////// Layered Offenses START /////
                try {
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.1")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.1", "7d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.2")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.2", "14d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.3")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.3", "30d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.4")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.4", "60d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.final")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.final", "90d");
                    }
                } catch (Exception err){
                    Utility.consoleLog(err.getMessage());
                }
                /////// Layered Offenses END /////
            } else {
                Utility.getCore().getConfig().createSection("punishments."+punish.name().toLowerCase());
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".reason")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".reason", punish.name().toLowerCase().replace("_", " "));
                }
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".time")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".time", "7d");
                }
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".type")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".type", "tempban");
                }
                if(Utility.getCore().getConfig().isSet("punishments."+punish.name().toLowerCase() + ".material")){

                } else {
                    Utility.getCore().getConfig().set("punishments." +punish.name().toLowerCase() + ".material", "book");
                }
                /////// Layered Offenses START /////
                try {
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.1")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.1", "7d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.2")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.2", "14d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.3")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.3", "30d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.4")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.4", "60d");
                    }
                    if (!Utility.getCore().getConfig().isSet("punishments." + punish.name().toLowerCase() + ".time.final")) {
                        Utility.getCore().getConfig().set("punishments." + punish.name().toLowerCase() + ".time.final", "90d");
                    }
                } catch (Exception err){
                    Utility.consoleLog(err.getMessage());
                }
                /////// Layered Offenses END /////
            }

        }
        Utility.getCore().saveConfig();
        Utility.getCore().getServer().getConsoleSender().sendMessage(logPrefix + "Loading Defaults!");
        Utility.getCore().reloadConfig();
    }


}
