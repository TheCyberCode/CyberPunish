package dev.thecybercode.plugin.cyberpunish.bukkit.database;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.UUID;

public class userBanData {
    public static HashMap<UUID, UUID> userToBan;

    static {
        userToBan = new HashMap<UUID, UUID>();
    }

    public static void setUserToBan(Player user, UUID value) {
        if (userToBan.containsKey(user.getUniqueId())) {
            userToBan.replace(user.getUniqueId(), value);
        } else {
            userToBan.put(user.getUniqueId(), value);
        }
        return;
    }

    public static UUID getUUIDToBan(Player user) {
        if (userToBan.isEmpty()) {
            return null;
        } else {
            if (!userToBan.containsKey(user.getUniqueId())) {
                return null;
            } else {
                return userToBan.get(user.getUniqueId());
            }
        }
    }
    public static OfflinePlayer getPlayerToBan(Player user){
        if (userToBan.isEmpty()) {
            return null;
        } else {
            if (!userToBan.containsKey(user.getUniqueId())) {
                return null;
            } else {
                final OfflinePlayer victim = Bukkit.getOfflinePlayer(userToBan.get(user.getUniqueId()));
                if(victim == null){
                    return null;
                } else {
                    return victim;
                }
            }
        }
    }
}
