package dev.thecybercode.plugin.cyberpunish.bukkit.database;

import dev.thecybercode.plugin.cybstaffchat.users.UserManager;

import java.util.HashMap;
import java.util.UUID;

public class PunishData {
    protected static PunishData punishData;
    public static HashMap<UUID, UUID> victim;

    static {
        victim = new HashMap<UUID, UUID>();
    }
}
