package dev.thecybercode.plugin.cyberpunish.bukkit.database;

import dev.thecybercode.plugin.cyberpunish.bukkit.utils.Utility;

import java.util.List;

public class PunishTypes {
    ////public static Enumeration CUSTOM_MENU = Collections.enumeration(CUSTOM_MENU_LIST());

    public static CUSTOM_GUI[] CUSTOM_MENU_LIST() {
        List list = Utility.getCore().getConfig().getList("custom-menu");
        PunishTypes.CUSTOM_GUI[] values = Utility.getCore().getConfig().getList("custom-menu").toArray(new CUSTOM_GUI[0]);
        ////  CUSTOM_MENU = Utility.getCore().getConfig().getList("custom-menu").toArray(new CUSTOM_MENU[0]);
        return values;
    }

    public enum PVP {
        AUTOCLICKER, REACH, FIGHTBOT, AIMBOT, CRITICALS, PVP_HACKS;
    }

    public enum AURA {
        KILLAURA, TP_AURA, CLICK_AURA, MULTI_AURA, OTHER_AURA;
    }

    public enum MOVEMENT {
        SPEED, B_HOP, FLY, NO_SLOW, SPIDER, NO_FALL, JESUS, PHASE, MOVEMENT_HACKS, BLINK, DOLPHIN;
    }

    public enum CHAT {
        SPAM, STAFF_DISRESPECT, DISCRIMINATION, DISRESPECT, RUDENESS, SWEARING, CHAT_VIOLATION, CHAT_BOT, THREATS, ADVERTISING
    }

    public enum AUTO {
        AUTO_ARMOUR, AUTO_MINE, AUTO_FISH, AUTO_EAT, AUTO_ATTACK, AUTO_SHOOT, AUTO_SWORD, AUTO_TOOL, BOT
    }

    public enum EXPLOIT {
        EXPLOITING_BUGS, EXPLOIT_HACKS, EXPLOITING
    }

    public enum OTHERHACKS {
        CHEST_ESP, FORCEFIELD, GLIDE, HIGH_JUMP, HEADLESS, DERP, MORE_INVENTORY, NUKER, REGEN, TRACERS, TWERK, HACKED_CLIENT, XRAY, FREECAM
    }

    public enum OTHER_PUNISH {
        COMPRIMISED_ACCOUNT, MANUAL_PUNISHMENT, CHEATING, UNFAIR_ADVANTAGE, ILLEGAL_MODS
    }


    public enum CUSTOM_GUI {
//        getCUSTOM_GUI();
//
//
    }
}
